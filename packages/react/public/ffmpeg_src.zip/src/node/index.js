const defaultOptions = require('./defaultOptions');
const getCreateFFmpegCore = require('./getCreateFFmpegCore');
const fetchFile = require('./fetchFile');

module.exports = {
  defaultOptions,
  getCreateFFmpegCore,
  fetchFile,
};
